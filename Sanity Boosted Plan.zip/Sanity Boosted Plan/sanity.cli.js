import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'lrf1izul',
    dataset: 'production'
  }
})
